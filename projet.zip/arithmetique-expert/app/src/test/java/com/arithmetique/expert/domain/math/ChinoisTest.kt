package com.arithmetique.expert.domain.math

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ChinoisTest {

    @Test
    fun exempleObligatoire_x5mod7_x7mod5() {
        val sol = Chinois.resoudre(
            listOf(ClasseSolution(5L, 7L), ClasseSolution(7L, 5L))
        )
        assertNotNull(sol)
        assertEquals(12L, sol!!.reste)
        assertEquals(35L, sol.modulo)
        // Vérification par substitution
        assertEquals(5L, Congruences.mod(12L, 7L))
        assertEquals(Congruences.mod(7L, 5L), Congruences.mod(12L, 5L))
    }

    @Test
    fun deuxCongruences_compareAvecRechercheExhaustive() {
        for (n1 in 1L..12L) {
            for (n2 in 1L..12L) {
                for (a1 in 0L until n1) {
                    for (a2 in 0L until n2) {
                        val borne = Euclide.ppcm(n1, n2)
                        val attendues = (0L until borne).filter { x ->
                            Congruences.mod(x, n1) == a1 && Congruences.mod(x, n2) == a2
                        }
                        val sol = Chinois.resoudre(listOf(ClasseSolution(a1, n1), ClasseSolution(a2, n2)))
                        if (attendues.isEmpty()) {
                            assertNull("incompatible: x=$a1 mod $n1, x=$a2 mod $n2", sol)
                        } else {
                            assertNotNull("compatible: x=$a1 mod $n1, x=$a2 mod $n2", sol)
                            assertEquals(borne, sol!!.modulo)
                            assertEquals(listOf(sol.reste), attendues)
                        }
                    }
                }
            }
        }
    }

    @Test
    fun troisCongruences_exempleConnu() {
        // x = 2 (3), x = 3 (5), x = 2 (7) -> x = 23 (105)
        val sol = Chinois.resoudre(
            listOf(ClasseSolution(2L, 3L), ClasseSolution(3L, 5L), ClasseSolution(2L, 7L))
        )
        assertNotNull(sol)
        assertEquals(23L, sol!!.reste)
        assertEquals(105L, sol.modulo)
    }
}
