package com.arithmetique.expert.domain.math

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DiophanteTest {

    @Test
    fun existenceEtFamilleGenerale() {
        for (a in -12L..12L) {
            for (b in -12L..12L) {
                if (a == 0L && b == 0L) continue
                for (c in -20L..20L) {
                    val d = Euclide.pgcd(a, b)
                    val sol = Diophante.resoudre(a, b, c)
                    if (c % d != 0L) {
                        assertNull("pas de solution pour ${a}x + ${b}y = $c", sol)
                    } else {
                        assertNotNull("solution pour ${a}x + ${b}y = $c", sol)
                        for (k in -5L..5L) {
                            val x = sol!!.x0 + sol.pasX * k
                            val y = sol.y0 + sol.pasY * k
                            assertEquals("substitution k=$k pour ${a}x + ${b}y = $c", c, a * x + b * y)
                        }
                    }
                }
            }
        }
    }

    @Test
    fun aucuneSolutionHorsFamille_exempleConnu() {
        // 7x + 5y = 1 : les solutions entieres sont exactement x = x0 + 5k, y = y0 - 7k
        val sol = Diophante.resoudre(7L, 5L, 1L)
        assertNotNull(sol)
        for (x in -30L..30L) {
            for (y in -30L..30L) {
                if (7L * x + 5L * y == 1L) {
                    val k = (x - sol!!.x0) / sol.pasX
                    assertEquals(0L, (x - sol.x0) % sol.pasX)
                    assertEquals(sol.y0 + sol.pasY * k, y)
                }
            }
        }
    }
}
