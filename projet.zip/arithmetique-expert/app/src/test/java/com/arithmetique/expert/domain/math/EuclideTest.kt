package com.arithmetique.expert.domain.math

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EuclideTest {

    private fun pgcdNaif(a: Long, b: Long): Long {
        if (a == 0L && b == 0L) return 0L
        var meilleur = 1L
        val borne = maxOf(Math.abs(a), Math.abs(b))
        for (d in 1L..borne) {
            if (a % d == 0L && b % d == 0L) meilleur = d
        }
        return meilleur
    }

    @Test
    fun divisionEuclidienne_exemplesConnus() {
        val d1 = Euclide.divisionEuclidienne(17L, 5L)
        assertEquals(3L, d1.q)
        assertEquals(2L, d1.r)
        val d2 = Euclide.divisionEuclidienne(-17L, 5L)
        assertEquals(-4L, d2.q)
        assertEquals(3L, d2.r)
    }

    @Test
    fun divisionEuclidienne_proprieteGenerale() {
        for (a in -60L..60L) {
            for (b in -12L..12L) {
                if (b == 0L) continue
                val d = Euclide.divisionEuclidienne(a, b)
                assertEquals("a = bq + r pour a=$a b=$b", a, b * d.q + d.r)
                assertTrue("0 <= r < |b| pour a=$a b=$b", d.r >= 0L && d.r < Math.abs(b))
            }
        }
    }

    @Test
    fun pgcd_compareAvecMethodeNaive() {
        for (a in -40L..40L) {
            for (b in -40L..40L) {
                assertEquals("pgcd($a,$b)", pgcdNaif(a, b), Euclide.pgcd(a, b))
            }
        }
    }

    @Test
    fun pgcdPpcm_produitEgalProduit() {
        for (a in 1L..40L) {
            for (b in 1L..40L) {
                assertEquals(a * b, Euclide.pgcd(a, b) * Euclide.ppcm(a, b))
            }
        }
        assertEquals(0L, Euclide.ppcm(0L, 5L))
    }

    @Test
    fun etapes_dernierDiviseurEstLePgcd() {
        val etapes = Euclide.etapes(252L, 198L)
        assertEquals(4, etapes.size)
        assertEquals(0L, etapes.last().r)
        assertEquals(18L, etapes.last().b)
        for (e in etapes) {
            assertEquals(e.a, e.b * e.q + e.r)
        }
        for (a in 1L..40L) {
            for (b in 1L..40L) {
                assertEquals(Euclide.pgcd(a, b), Euclide.etapes(a, b).last().b)
            }
        }
    }
}
