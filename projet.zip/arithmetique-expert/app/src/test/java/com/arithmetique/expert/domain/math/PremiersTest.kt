package com.arithmetique.expert.domain.math

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PremiersTest {

    private fun premierNaif(n: Long): Boolean {
        if (n < 2L) return false
        for (d in 2L until n) {
            if (n % d == 0L) return false
        }
        return true
    }

    @Test
    fun estPremier_compareAvecMethodeNaive() {
        for (n in -5L..2000L) {
            assertEquals("estPremier($n)", premierNaif(n), Premiers.estPremier(n))
        }
    }

    @Test
    fun factorisation_reconstruitLeNombre() {
        for (n in 2L..3000L) {
            val f = Premiers.factorisation(n)
            var produit = 1L
            for ((p, e) in f) {
                assertTrue("$p doit être premier", Premiers.estPremier(p))
                for (i in 1..e) produit *= p
            }
            assertEquals("produit des facteurs de $n", n, produit)
        }
        assertEquals(listOf(Pair(2L, 2), Pair(3L, 2), Pair(5L, 1)), Premiers.factorisation(180L))
    }

    @Test
    fun diviseurs_exempleConnu() {
        assertEquals(listOf(1L, 2L, 3L, 4L, 6L, 12L), Premiers.diviseurs(12L))
        assertEquals(listOf(1L, 7L), Premiers.diviseurs(7L))
        assertEquals(listOf(1L), Premiers.diviseurs(1L))
    }

    @Test
    fun crible_coherentAvecEstPremier() {
        val c = Premiers.crible(200)
        assertEquals(46, c.size)
        for (n in 0..200) {
            assertEquals(Premiers.estPremier(n.toLong()), c.contains(n))
        }
        assertEquals(25, Premiers.crible(100).size)
    }
}
