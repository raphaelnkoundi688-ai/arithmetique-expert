package com.arithmetique.expert.domain.math

import java.math.BigInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CongruencesTest {

    @Test
    fun mod_resteToujoursPositif() {
        assertEquals(3L, Congruences.mod(-17L, 5L))
        assertEquals(2L, Congruences.mod(17L, 5L))
        assertEquals(0L, Congruences.mod(-10L, 5L))
    }

    @Test
    fun inverse_existeSiEtSeulementSiPremiersEntreEux() {
        for (n in 1L..30L) {
            for (a in -35L..35L) {
                val inv = Congruences.inverse(a, n)
                if (Euclide.pgcd(a, n) == 1L) {
                    assertTrue("inverse de $a mod $n", inv != null)
                    assertEquals("a*inv = 1 mod $n pour a=$a", 1L % n, Congruences.mod(a * inv!!, n))
                } else {
                    assertNull("pas d'inverse de $a mod $n", inv)
                }
            }
        }
    }

    @Test
    fun resoudreLineaire_compareAvecRechercheExhaustive() {
        for (n in 1L..20L) {
            for (a in -10L..25L) {
                for (b in -10L..25L) {
                    val attendues = (0L until n).filter { x -> Congruences.mod(a * x - b, n) == 0L }
                    val sol = Congruences.resoudreLineaire(a, b, n)
                    if (attendues.isEmpty()) {
                        assertNull("aucune solution pour ${a}x = $b mod $n", sol)
                    } else {
                        assertTrue("solution attendue pour ${a}x = $b mod $n", sol != null)
                        val obtenues = (0L until n).filter { x -> Congruences.mod(x, sol!!.modulo) == sol.reste }
                        assertEquals("ensemble des solutions pour ${a}x = $b mod $n", attendues, obtenues)
                    }
                }
            }
        }
    }

    @Test
    fun puissanceMod_compareAvecBigInteger() {
        for (base in -12L..12L) {
            for (e in 0L..20L) {
                for (n in 1L..15L) {
                    val attendu = BigInteger.valueOf(base).pow(e.toInt()).mod(BigInteger.valueOf(n)).toLong()
                    assertEquals("$base^$e mod $n", attendu, Congruences.puissanceMod(base, e, n))
                }
            }
        }
    }

    @Test
    fun puissanceMod_exempleConnu() {
        // 2^10 = 1024 = 7 x 146 + 2
        assertEquals(2L, Congruences.puissanceMod(2L, 10L, 7L))
    }
}
