package com.arithmetique.expert

import org.junit.Assert.assertEquals
import org.junit.Test

class SanityTest {
    @Test
    fun la_chaine_de_test_fonctionne() {
        assertEquals(4, 2 + 2)
    }
}
