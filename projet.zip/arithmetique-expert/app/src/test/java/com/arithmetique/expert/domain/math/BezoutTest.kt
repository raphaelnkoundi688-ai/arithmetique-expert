package com.arithmetique.expert.domain.math

import org.junit.Assert.assertEquals
import org.junit.Test

class BezoutTest {

    @Test
    fun identiteDeBezout_toutesPaires() {
        for (a in -40L..40L) {
            for (b in -40L..40L) {
                val bz = BezoutCalc.calculer(a, b)
                assertEquals("a*u + b*v = pgcd pour a=$a b=$b", bz.pgcd, a * bz.u + b * bz.v)
                assertEquals("pgcd pour a=$a b=$b", Euclide.pgcd(a, b), bz.pgcd)
            }
        }
    }

    @Test
    fun exempleConnu_240_46() {
        val bz = BezoutCalc.calculer(240L, 46L)
        assertEquals(2L, bz.pgcd)
        assertEquals(2L, 240L * bz.u + 46L * bz.v)
    }
}
