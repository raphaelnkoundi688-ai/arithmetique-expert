package com.arithmetique.expert.domain.math

import kotlin.math.abs

/** Résultat d'une division euclidienne : a = b × q + r avec 0 ≤ r < |b|. */
data class DivisionEuclidienne(val a: Long, val b: Long, val q: Long, val r: Long)

object Euclide {

    /** Division euclidienne de a par b (b ≠ 0), avec toujours 0 ≤ r < |b|. */
    fun divisionEuclidienne(a: Long, b: Long): DivisionEuclidienne {
        require(b != 0L) { "Le diviseur doit être non nul." }
        var q = a / b
        var r = a % b
        if (r < 0L) {
            if (b > 0L) {
                r += b
                q -= 1L
            } else {
                r -= b
                q += 1L
            }
        }
        return DivisionEuclidienne(a, b, q, r)
    }

    /** PGCD positif de a et b (pgcd(0, 0) = 0). */
    fun pgcd(a: Long, b: Long): Long {
        var x = abs(a)
        var y = abs(b)
        while (y != 0L) {
            val t = x % y
            x = y
            y = t
        }
        return x
    }

    /** PPCM positif de a et b (0 si l'un des deux est nul). */
    fun ppcm(a: Long, b: Long): Long {
        if (a == 0L || b == 0L) return 0L
        return abs(Math.multiplyExact(a / pgcd(a, b), b))
    }

    /**
     * Divisions successives de l'algorithme d'Euclide appliqué à |a| et |b|.
     * La dernière division a un reste nul ; son diviseur est le PGCD.
     */
    fun etapes(a: Long, b: Long): List<DivisionEuclidienne> {
        var x = abs(a)
        var y = abs(b)
        val liste = mutableListOf<DivisionEuclidienne>()
        while (y != 0L) {
            val d = divisionEuclidienne(x, y)
            liste.add(d)
            x = y
            y = d.r
        }
        return liste
    }
}
