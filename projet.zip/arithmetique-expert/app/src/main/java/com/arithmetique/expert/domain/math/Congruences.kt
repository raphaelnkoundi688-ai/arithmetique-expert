package com.arithmetique.expert.domain.math

import java.math.BigInteger

/** Ensemble des x tels que x ≡ reste (mod modulo). */
data class ClasseSolution(val reste: Long, val modulo: Long)

object Congruences {

    /** Reste de a modulo n, toujours dans [0, n[ (n > 0). */
    fun mod(a: Long, n: Long): Long {
        require(n > 0L) { "Le module doit être strictement positif." }
        val r = a % n
        return if (r < 0L) r + n else r
    }

    /** Vrai si a ≡ b (mod n). */
    fun sontCongrus(a: Long, b: Long, n: Long): Boolean = mod(a, n) == mod(b, n)

    /** Inverse de a modulo n dans [0, n[, ou null s'il n'existe pas (pgcd(a, n) ≠ 1). */
    fun inverse(a: Long, n: Long): Long? {
        require(n > 0L) { "Le module doit être strictement positif." }
        val bz = BezoutCalc.calculer(mod(a, n), n)
        if (bz.pgcd != 1L) return null
        return mod(bz.u, n)
    }

    /**
     * Résout a·x ≡ b (mod n).
     * Renvoie la classe solution x ≡ reste (mod modulo), ou null s'il n'y a aucune solution.
     */
    fun resoudreLineaire(a: Long, b: Long, n: Long): ClasseSolution? {
        require(n > 0L) { "Le module doit être strictement positif." }
        val d = Euclide.pgcd(a, n)
        val bm = mod(b, n)
        if (bm % d != 0L) return null
        val a1 = mod(a, n) / d
        val b1 = bm / d
        val n1 = n / d
        val inv = inverse(a1, n1) ?: return null
        return ClasseSolution(mod(Math.multiplyExact(b1, inv), n1), n1)
    }

    /** base^exposant mod n par exponentiation rapide (exposant ≥ 0, n > 0). */
    fun puissanceMod(base: Long, exposant: Long, n: Long): Long {
        require(n > 0L) { "Le module doit être strictement positif." }
        require(exposant >= 0L) { "L'exposant doit être positif ou nul." }
        return BigInteger.valueOf(base)
            .modPow(BigInteger.valueOf(exposant), BigInteger.valueOf(n))
            .toLong()
    }
}
