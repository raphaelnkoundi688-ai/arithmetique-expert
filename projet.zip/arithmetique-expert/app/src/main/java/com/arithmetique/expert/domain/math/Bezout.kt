package com.arithmetique.expert.domain.math

/** Identité de Bézout : a × u + b × v = pgcd (pgcd ≥ 0). */
data class Bezout(val a: Long, val b: Long, val pgcd: Long, val u: Long, val v: Long)

object BezoutCalc {

    /** Algorithme d'Euclide étendu. Vérifie toujours a·u + b·v = pgcd(a, b). */
    fun calculer(a: Long, b: Long): Bezout {
        var ancienR = a
        var r = b
        var ancienS = 1L
        var s = 0L
        var ancienT = 0L
        var t = 1L
        while (r != 0L) {
            val q = ancienR / r
            val nouveauR = ancienR - q * r
            ancienR = r
            r = nouveauR
            val nouveauS = ancienS - q * s
            ancienS = s
            s = nouveauS
            val nouveauT = ancienT - q * t
            ancienT = t
            t = nouveauT
        }
        if (ancienR < 0L) {
            ancienR = -ancienR
            ancienS = -ancienS
            ancienT = -ancienT
        }
        return Bezout(a, b, ancienR, ancienS, ancienT)
    }
}
