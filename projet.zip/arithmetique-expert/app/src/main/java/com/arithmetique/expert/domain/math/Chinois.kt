package com.arithmetique.expert.domain.math

object Chinois {

    /** Fusionne deux congruences x ≡ r1 (mod n1) et x ≡ r2 (mod n2), ou null si incompatibles. */
    fun fusionner(c1: ClasseSolution, c2: ClasseSolution): ClasseSolution? {
        val n1 = c1.modulo
        val n2 = c2.modulo
        // x = r1 + n1·k, avec n1·k ≡ r2 - r1 (mod n2)
        val k = Congruences.resoudreLineaire(n1, c2.reste - c1.reste, n2) ?: return null
        val ppcm = Math.multiplyExact(n1 / Euclide.pgcd(n1, n2), n2)
        val x = Math.addExact(c1.reste, Math.multiplyExact(n1, k.reste))
        return ClasseSolution(Congruences.mod(x, ppcm), ppcm)
    }

    /** Résout un système de congruences (modules non nécessairement premiers entre eux). */
    fun resoudre(systeme: List<ClasseSolution>): ClasseSolution? {
        require(systeme.isNotEmpty()) { "Le système est vide." }
        val premiere = systeme[0]
        var courant = ClasseSolution(Congruences.mod(premiere.reste, premiere.modulo), premiere.modulo)
        for (i in 1 until systeme.size) {
            courant = fusionner(courant, systeme[i]) ?: return null
        }
        return courant
    }
}
