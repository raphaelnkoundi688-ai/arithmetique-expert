package com.arithmetique.expert.domain.math

/**
 * Ensemble des solutions entières de a·x + b·y = c :
 * x = x0 + pasX·k, y = y0 + pasY·k, pour tout entier k.
 */
data class SolutionDiophantienne(val x0: Long, val y0: Long, val pasX: Long, val pasY: Long)

object Diophante {

    /** Résout a·x + b·y = c (a et b non tous deux nuls). Renvoie null si pgcd(a, b) ne divise pas c. */
    fun resoudre(a: Long, b: Long, c: Long): SolutionDiophantienne? {
        require(a != 0L || b != 0L) { "a et b ne peuvent pas être tous les deux nuls." }
        val bz = BezoutCalc.calculer(a, b)
        val d = bz.pgcd
        if (c % d != 0L) return null
        val m = c / d
        return SolutionDiophantienne(
            x0 = Math.multiplyExact(m, bz.u),
            y0 = Math.multiplyExact(m, bz.v),
            pasX = b / d,
            pasY = -(a / d)
        )
    }
}
