package com.arithmetique.expert.domain.math

object Premiers {

    /** Vrai si n est un nombre premier. */
    fun estPremier(n: Long): Boolean {
        if (n < 2L) return false
        if (n < 4L) return true
        if (n % 2L == 0L) return false
        var i = 3L
        while (i * i <= n) {
            if (n % i == 0L) return false
            i += 2L
        }
        return true
    }

    /** Décomposition de n ≥ 2 en facteurs premiers : liste de (premier, exposant) croissante. */
    fun factorisation(n: Long): List<Pair<Long, Int>> {
        require(n >= 2L) { "n doit être au moins égal à 2." }
        var reste = n
        val resultat = mutableListOf<Pair<Long, Int>>()
        var p = 2L
        while (p * p <= reste) {
            var exposant = 0
            while (reste % p == 0L) {
                reste /= p
                exposant += 1
            }
            if (exposant > 0) resultat.add(Pair(p, exposant))
            p += if (p == 2L) 1L else 2L
        }
        if (reste > 1L) resultat.add(Pair(reste, 1))
        return resultat
    }

    /** Diviseurs positifs de n ≥ 1, dans l'ordre croissant. */
    fun diviseurs(n: Long): List<Long> {
        require(n >= 1L) { "n doit être au moins égal à 1." }
        val liste = mutableListOf<Long>()
        var d = 1L
        while (d * d <= n) {
            if (n % d == 0L) {
                liste.add(d)
                if (d != n / d) liste.add(n / d)
            }
            d += 1L
        }
        liste.sort()
        return liste
    }

    /** Crible d'Ératosthène : nombres premiers inférieurs ou égaux à limite. */
    fun crible(limite: Int): List<Int> {
        if (limite < 2) return emptyList()
        val composite = BooleanArray(limite + 1)
        val premiers = mutableListOf<Int>()
        for (i in 2..limite) {
            if (!composite[i]) {
                premiers.add(i)
                var j = i.toLong() * i
                while (j <= limite) {
                    composite[j.toInt()] = true
                    j += i
                }
            }
        }
        return premiers
    }
}
